# MiningClawd 报告样式规范

> 本文件由 SKILL.md 拆分而来，包含完整的 CSS / HTML 模板规范。
> 生成报告时参阅本文件获取样式细节。

---

## 第三步：HTML + CSS 样式规范（完整）

## 第三步：手写 HTML + CSS

参考附件 HTML 结构，必须包含以下核心机制：

```css
@page { size: A4; margin: 0 }
.page { width: 210mm; min-height: 297mm; page-break-after: always; overflow: hidden }
```

> ⚠️ **防溢出规则（强制）**
>
> `min-height: 297mm` 允许内容超出 A4 边界，Playwright 在物理纸张处截断时完全不感知 `.page` 边界，导致内容被拦腰截断。必须同时应用以下两层防御：

**第一层 — CSS：对所有块级组件声明 `break-inside: avoid`**

```css
/* 禁止浏览器在组件内部跨页截断 */
.key-points,
.data-table,
.risk-box,
.highlight,
.disclaimer,
.sidebar-col,
.sb-section {
  break-inside: avoid;
  page-break-inside: avoid;
}
```

**第二层 — JS：PDF 输出前调用 `fixOverflow()` 自动修复溢出**

在每个报告生成脚本中，`page.pdf()` 之前插入：

```js
const { fixOverflow } = require('./scripts/splitOverflow.cjs');

// ... 构建 HTML、goto 加载 ...

await fixOverflow(playwrightPage);   // ← 自动测量、分割、更新页码
await playwrightPage.pdf({
  path: outputPath,
  format: 'A4',
  printBackground: true,
  preferCSSPageSize: true,
});
```

`fixOverflow` 逻辑（位于 `scripts/splitOverflow.cjs`）：
1. 遍历所有 `.page`，测量实际渲染高度（px）
2. 若超过 A4（≈1122px），从末尾向前找分割点，将溢出子元素移入新建 `.page`
3. 循环直到全部收敛，最后统一更新页码 `Page X / Y`

**内容预算参考**（避免单页内容过满）：

| 页面类型 | 可用高度（去掉上下边距 38mm） | 约可放行数 |
|---|---|---|
| 全宽页（摘要/目录） | ~259mm ≈ 979px | ≈ 47 行正文 |
| 侧栏页（main-col 75%） | ~259mm | ≈ 47 行正文 |
| 含全宽图表的页 | 图表建议 `max-height: 200px`，留足文字空间 |

**必须实现的结构与组件**：

| 组件 | 要求 |
|---|---|
| `.cover` | 深炭色背景 `#0f1115`；`.glow1/.glow2/.glow3`（radial-gradient）+ `.streak/.streak2`（linear-gradient） |
| `.content-page` | Flex 布局：`.sidebar-col`（25%）+ `.main-col`（75%） |
| 页眉 | 左侧 Logo + 类别/日期；下方 2px 品牌色线 `#14b8a6` |
| 侧栏 | 背景 `#f8fafb`；含章节摘要、关键数据、AI 信号（▲/●/▼）、页码 `Page X / Y` |
| `.data-table` | 深色表头 + 交替行底色 |
| `.key-points` | 浅灰背景、圆角 8px、`▸` 前缀、带 "AI GENERATED" 徽章 |
| `.highlight` | 左侧 3px 品牌色实线、品牌色 5% 背景块 |
| `.risk-box` | 背景 `#fef2f2`、红色标题、`⚠` 前缀 |
| **`.back-cover`**（必须） | 深炭色背景同封面；光晕与光线错位排布；居中大 Logo + 品牌名 + tagline；`.bc-divider` 渐变分隔线；`.bc-info` 三栏（About / Coverage / Contact）；`.bc-footer` 含免责声明 + 版权行；`page-break-after:auto` 防止末尾多余空白页 |

**颜色语义**（根据数据正负/评级自动选择）：

| 含义 | 颜色 |
|---|---|
| 上涨 / Strong Buy | `#22c55e` |
| Buy | `#86efac` |
| 中性 / Hold | `#94a3b8` |
| Sell | `#f87171` |
| 下跌 / Strong Sell | `#ef4444` |

**字体**：`"Space Grotesk", system-ui, sans-serif`（数字/英文）；`Noto Sans SC` 或系统中文字体（中文正文）。网络受限时使用系统字体回退，保持字号/字重层级。

**字体大小规范**（参考顶级投行报告标准 - Goldman Sachs, Morgan Stanley）：

| 元素 | 字号 | 字重 | 说明 |
|---|---|---|---|
| `body` 基础 | 12px | 400 | 基础字体大小 |
| `p` 正文段落 | 11.5px | 400 | 约10.5pt，符合投行标准 |
| `h2` 一级标题 | 17px | 700 | 章节标题 |
| `h3` 二级标题 | 13.5px | 600 | 小节标题 |
| `.cover h1` 封面标题 | 38px | 700 | 封面主标题 |
| `.cover .subtitle` | 14px | 400 | 封面副标题 |
| `.cover .eyebrow` | 12px | 500 | 封面眉标 |
| `.key-points .title` | 12px | 700 | 关键要点标题 |
| `.key-points li` | 11px | 400 | 关键要点列表项 |
| `.highlight` | 11px | 400 | 高亮文本框 |
| 图表标题 | 14px | 600 | Chart Title，SVG 内实际写 28px（deviceScaleFactor 2×）|
| `.data-table` | 10.5px | 400 | 表格内容 |
| `.data-table th` | 9.5px | 600 | 表格表头 |
| `.sb-title` 侧栏标题 | 9px | 700 | 侧栏章节标题 |
| `.sb-item` 侧栏项 | 10px | 400 | 侧栏数据项 |
| `.sb-highlight` | 10.5px | 600 | 侧栏摘要高亮 |
| `.risk-box .rtitle` | 11.5px | 700 | 风险提示标题 |
| `.risk-box li` | 10.5px | 400 | 风险提示列表 |
| `.disclaimer` | 9px | 400 | 免责声明 |
| `.sb-pagenum` 页码 | 9px | 400 | 页面编号 |
| `.page-bar .right` | 10px | 400 | 页眉日期 |

**重要说明**：
- 正文字号 11.5px（约10.5pt）符合国际投行研究报告标准
- 所有字号已针对 PDF 输出优化，确保打印和屏幕阅读的最佳可读性
- 中英文混排时保持统一字号，通过字体族（Noto Sans SC / Inter）自动适配

---



---

## 封底设计规范（Back Cover）完整模板

## 封底设计规范（Back Cover）

> ⚠️ **强制要求**：每份报告必须以 `.back-cover` 页结尾，不可省略。

**CSS（直接复制到生成的 HTML 的 `<style>` 中）**：

```css
/* ========== BACK COVER 封底 ========== */
.back-cover{background:#0f1115;color:#fff;display:flex;flex-direction:column;min-height:297mm;position:relative;overflow:hidden;page-break-after:auto}
.bc-top{padding:20mm 28mm 0;display:flex;justify-content:space-between;align-items:center;position:relative;z-index:1}
.bc-center{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;position:relative;z-index:1;padding:0 28mm;text-align:center}
.bc-divider{width:160px;height:1px;background:linear-gradient(90deg,transparent,#14b8a6,#5eead4,#14b8a6,transparent);margin:18px auto}
.bc-info{display:grid;grid-template-columns:1fr 1fr 1fr;gap:28px;margin-top:28px;width:100%;max-width:500px;text-align:left}
.bc-col-title{font-size:8px;color:#14b8a6;letter-spacing:2px;text-transform:uppercase;font-weight:600;margin-bottom:8px;padding-bottom:5px;border-bottom:1px solid rgba(20,184,166,0.18)}
.bc-col-body{font-size:9.5px;color:#9ca3af;line-height:1.9}
.bc-col-body strong{color:#d1d5db;font-weight:500}
.bc-footer{border-top:1px solid rgba(255,255,255,0.06);padding:14px 28mm 18mm;position:relative;z-index:1}
.bc-disclaimer{font-size:7.5px;color:#4b5563;line-height:1.7;text-align:center;max-width:75%;margin:0 auto 10px}
.bc-copyright{display:flex;justify-content:space-between;align-items:center;font-size:8px}
```

**HTML 模板（放在 `</body>` 前，所有内容页之后）**：

```html
<!-- BACK COVER 封底 -->
<div class="page back-cover">
  <div class="glow1" style="top:55%;opacity:0.6"></div>
  <div class="glow2" style="bottom:auto;top:8%;opacity:0.6"></div>
  <div class="glow3" style="right:auto;left:18%;top:42%;opacity:0.45"></div>
  <div class="streak" style="top:36%"></div>
  <div class="streak2" style="top:63%"></div>

  <div class="bc-top">
    <div style="font-size:8px;color:#374151;letter-spacing:2px;text-transform:uppercase;font-weight:500">End of Report · 报告完结</div>
    <div style="font-size:8px;color:#374151">MiningClawd Intelligence Systems</div>
  </div>

  <div class="bc-center">
    <svg width="60" height="60" viewBox="0 0 48 48" fill="none">
      <rect x="2" y="2" width="44" height="44" rx="12" fill="#0f1115" stroke="#14b8a6" stroke-width="1.2"/>
      <path d="M12 34 L12 20 L18 14" stroke="#14b8a6" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
      <path d="M18 14 L24 26 L30 14" stroke="#14b8a6" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
      <path d="M30 14 L36 20 L36 34" stroke="#14b8a6" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
      <line x1="16" y1="28" x2="32" y2="28" stroke="#14b8a6" stroke-width="1" opacity="0.4"/>
      <path d="M22 37 L24 40 L26 37 L24 34 Z" fill="#14b8a6" opacity="0.85"/>
    </svg>
    <div style="margin-top:18px">
      <span style="font-family:'Space Grotesk',sans-serif;font-weight:700;font-style:italic;font-size:30px">
        <span style="color:#fff">Mining</span><span style="color:#14b8a6">Clawd</span>
      </span>
    </div>
    <div style="font-size:10px;color:#14b8a6;letter-spacing:3.5px;text-transform:uppercase;font-weight:500;margin-top:7px">Mining Intelligence · AI-Powered</div>
    <div class="bc-divider"></div>
    <div class="bc-info">
      <div>
        <div class="bc-col-title">About</div>
        <div class="bc-col-body">MiningClawd 是基于 AI 多因子模型的矿业经济研究平台，专注于为机构投资者提供全球宏观与矿业专项研究服务。</div>
      </div>
      <div>
        <div class="bc-col-title">Coverage</div>
        <div class="bc-col-body">
          <strong>宏观研究</strong> Global Macro<br>
          <strong>大宗商品</strong> Commodities<br>
          <strong>矿业股票</strong> Mining Equities<br>
          <strong>政策追踪</strong> Policy Monitor
        </div>
      </div>
      <div>
        <div class="bc-col-title">Contact</div>
        <div class="bc-col-body">
          <strong>Email</strong><br>info@lynaimining.com<br><br>
          <strong>Platform</strong><br>MiningClawd AI
        </div>
      </div>
    </div>
  </div>

  <div class="bc-footer">
    <div class="bc-disclaimer">本报告由 MiningClawd AI Intelligence Systems 自动生成，内容仅供机构投资者参考，不构成投资建议或要约。市场有风险，投资需谨慎。所有数据来源均已在报告各章节内标注。This report is generated by MiningClawd AI and is intended for institutional investors only. It does not constitute investment advice.</div>
    <div class="bc-copyright">
      <span style="color:#374151">CONFIDENTIAL — For Institutional Investors Only</span>
      <span style="color:#14b8a6;font-weight:600">MiningClawd AI Intelligence Systems © [年份]</span>
      <span style="color:#374151">All Rights Reserved</span>
    </div>
  </div>
</div>
```

**设计要点**：
- 光晕（`.glow1/.glow2/.glow3`）与封面错位排布，形成视觉呼应但避免重复
- `.bc-divider` 渐变线是封面与封底的视觉锚点，宽度固定 160px
- 三栏等宽 `1fr 1fr 1fr`，不可改为两栏或单栏
- `page-break-after:auto` 是防止末尾产生空白页的关键，不可删除

---



---

## 大宗商品颜色规范（Commodity Color System）完整规范

## 大宗商品颜色规范（Commodity Color System）

每种商品拥有独立识别色，用于**品种标识**，不传达涨跌方向（方向性信号仍由绿/红和五档评级色系承载）。

**CSS 变量**（在 `:root` 中声明，直接复制到生成的 HTML）：

```css
:root {
  /* Base Metals 基本金属 */
  --cu:#e07b39; --cu-bg:rgba(224,123,57,0.08);   /* Copper 铜 */
  --al:#94a3b8; --al-bg:rgba(148,163,184,0.08);  /* Aluminum 铝 */
  --fe:#dc2626; --fe-bg:rgba(220,38,38,0.08);    /* Iron Ore 铁矿石 */
  --zn:#0891b2; --zn-bg:rgba(8,145,178,0.08);    /* Zinc 锌 */
  --ni:#64748b; --ni-bg:rgba(100,116,139,0.08);  /* Nickel 镍 */
  --pb:#52525b; --pb-bg:rgba(82,82,91,0.08);     /* Lead 铅 */
  /* Precious Metals 贵金属 */
  --au:#f59e0b; --au-bg:rgba(245,158,11,0.08);   /* Gold 黄金 */
  --ag:#cbd5e1; --ag-bg:rgba(203,213,225,0.08);  /* Silver 白银 */
  --pt:#67e8f9; --pt-bg:rgba(103,232,249,0.08);  /* Platinum 铂金 */
  --pd:#a78bfa; --pd-bg:rgba(167,139,250,0.08);  /* Palladium 钯金 */
  /* New Energy Minerals 新能源矿产 */
  --li:#8b5cf6; --li-bg:rgba(139,92,246,0.08);   /* Lithium 锂 */
  --co:#2563eb; --co-bg:rgba(37,99,235,0.08);    /* Cobalt 钴 */
  --mn:#c026d3; --mn-bg:rgba(192,38,211,0.08);   /* Manganese 锰 */
  --ree:#10b981;--ree-bg:rgba(16,185,129,0.08);  /* Rare Earth 稀土 */
  /* Energy 能源 */
  --oil:#92400e;--oil-bg:rgba(146,64,14,0.08);   /* Crude Oil 原油 */
  --gas:#38bdf8;--gas-bg:rgba(56,189,248,0.08);  /* Natural Gas 天然气 */
  --coal:#6b7280;--coal-bg:rgba(107,114,128,0.08);/* Coal 煤炭 */
  /* Agricultural 农产品 */
  --wht:#d97706;--wht-bg:rgba(217,119,6,0.08);   /* Wheat 小麦 */
  --corn:#84cc16;--corn-bg:rgba(132,204,22,0.08);/* Corn 玉米 */
  --soy:#22c55e;--soy-bg:rgba(34,197,94,0.08);   /* Soybean 大豆 */
}
```

**工具类 CSS**（必须包含在生成的 HTML 中）：

```css
/* 色点行内标签 — 用于表格品种名列 */
.comm{display:inline-flex;align-items:center;gap:4px;font-weight:600}
.comm::before{content:'';width:7px;height:7px;border-radius:50%;flex-shrink:0}
.comm-cu{color:var(--cu)}.comm-cu::before{background:var(--cu)}
.comm-al{color:var(--al)}.comm-al::before{background:var(--al)}
.comm-fe{color:var(--fe)}.comm-fe::before{background:var(--fe)}
.comm-zn{color:var(--zn)}.comm-zn::before{background:var(--zn)}
.comm-ni{color:var(--ni)}.comm-ni::before{background:var(--ni)}
.comm-pb{color:var(--pb)}.comm-pb::before{background:var(--pb)}
.comm-au{color:var(--au)}.comm-au::before{background:var(--au)}
.comm-ag{color:var(--ag)}.comm-ag::before{background:var(--ag)}
.comm-pt{color:var(--pt)}.comm-pt::before{background:var(--pt)}
.comm-pd{color:var(--pd)}.comm-pd::before{background:var(--pd)}
.comm-li{color:var(--li)}.comm-li::before{background:var(--li)}
.comm-co{color:var(--co)}.comm-co::before{background:var(--co)}
.comm-mn{color:var(--mn)}.comm-mn::before{background:var(--mn)}
.comm-ree{color:var(--ree)}.comm-ree::before{background:var(--ree)}
.comm-oil{color:var(--oil)}.comm-oil::before{background:var(--oil)}
.comm-gas{color:var(--gas)}.comm-gas::before{background:var(--gas)}
.comm-coal{color:var(--coal)}.comm-coal::before{background:var(--coal)}
.comm-wht{color:var(--wht)}.comm-wht::before{background:var(--wht)}
.comm-corn{color:var(--corn)}.comm-corn::before{background:var(--corn)}
.comm-soy{color:var(--soy)}.comm-soy::before{background:var(--soy)}

/* 圆角徽章 — 用于侧栏信号标注及正文行内提及 */
.comm-pill{padding:1px 6px;border-radius:10px;font-size:9px;font-weight:700;letter-spacing:0.3px;display:inline-block}
.pill-cu{background:var(--cu-bg);color:var(--cu);border:1px solid rgba(224,123,57,0.25)}
.pill-al{background:var(--al-bg);color:var(--al);border:1px solid rgba(148,163,184,0.25)}
.pill-fe{background:var(--fe-bg);color:var(--fe);border:1px solid rgba(220,38,38,0.25)}
.pill-zn{background:var(--zn-bg);color:var(--zn);border:1px solid rgba(8,145,178,0.25)}
.pill-ni{background:var(--ni-bg);color:var(--ni);border:1px solid rgba(100,116,139,0.25)}
.pill-pb{background:var(--pb-bg);color:var(--pb);border:1px solid rgba(82,82,91,0.25)}
.pill-au{background:var(--au-bg);color:var(--au);border:1px solid rgba(245,158,11,0.25)}
.pill-ag{background:var(--ag-bg);color:var(--ag);border:1px solid rgba(203,213,225,0.25)}
.pill-pt{background:var(--pt-bg);color:var(--pt);border:1px solid rgba(103,232,249,0.25)}
.pill-pd{background:var(--pd-bg);color:var(--pd);border:1px solid rgba(167,139,250,0.25)}
.pill-li{background:var(--li-bg);color:var(--li);border:1px solid rgba(139,92,246,0.25)}
.pill-co{background:var(--co-bg);color:var(--co);border:1px solid rgba(37,99,235,0.25)}
.pill-mn{background:var(--mn-bg);color:var(--mn);border:1px solid rgba(192,38,211,0.25)}
.pill-ree{background:var(--ree-bg);color:var(--ree);border:1px solid rgba(16,185,129,0.25)}
.pill-oil{background:var(--oil-bg);color:var(--oil);border:1px solid rgba(146,64,14,0.25)}
.pill-gas{background:var(--gas-bg);color:var(--gas);border:1px solid rgba(56,189,248,0.25)}
.pill-coal{background:var(--coal-bg);color:var(--coal);border:1px solid rgba(107,114,128,0.25)}
.pill-pt{background:var(--pt-bg);color:var(--pt);border:1px solid rgba(103,232,249,0.25)}
.pill-pd{background:var(--pd-bg);color:var(--pd);border:1px solid rgba(167,139,250,0.25)}
```

**使用规则**：
- 表格品种名列：`<span class="comm comm-cu">LME 铜</span>`
- 侧栏信号标注：`<span class="comm-pill pill-cu">Cu</span>`
- 商品色仅标识品种，所有商品色均避开品牌色 `#14b8a6` 色域

---



---

