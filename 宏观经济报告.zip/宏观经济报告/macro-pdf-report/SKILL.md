---
name: macro-pdf-report
description: 当用户要生成宏观经济报告时，生成 MiningClawd 风格的 A4 PDF，严格参照 assets/MiningClawd_MacroReport_Bilingual.html 的设计样式，内容以用户指定的内容填充。
---

# MiningClawd 宏观周报 PDF 报告生成

## 核心约束（优先级最高）

> **禁止臆造**：所有段落、数字、评级、表格数据、结论、引用必须能在原始 Word 文档中找到对应来源。缺失内容向用户索取原文，不得补写任何"合理猜测"。

- **唯一内容来源**：`澳大利亚矿业经济宏观分析报告_2026-03-12.docx`（用户明确更换来源时除外）
- **样式参考**：严格参照 `assets/MiningClawd_MacroReport_Bilingual.html` 的分页、封面光效、分栏与组件结构、图表配色
- **PDF 输出**：必须用 Playwright `page.pdf()`，不使用浏览器打印

---

## 第一步：收集输入信息

开始前确认以下内容（未提供则主动询问）：

| 信息项 | 说明 |
|---|---|
| 报告标题 | 如"全球矿业宏观经济周度观察报告" |
| 报告类别 | 如"宏观研究" |
| 报告日期 | 封面 + 页眉格式，如 `2025.07.14` / "2025年7月14日" |
| 报告期 | 如 `2025.07.07 — 2025.07.13`（可选） |
| 内容来源 | Word 文件路径，或请用户粘贴原文（见下方说明） |

**无法读取 `.docx` 时**，要求用户提供以下之一：
- 将 Word 正文（含表格）按章节复制粘贴到对话，或
- 导出为 `.txt / .md`，或
- 提供从 Word 另存的 PDF/HTML

---

## 第二步：内容结构化

将内容映射至以下默认章节（用户另有说明时以用户为准）：

1. 封面（标题、副标题、日期、说明）
2. 报告要点（带 "AI GENERATED" 徽章，3–6 条）
3. 目录
4. 一、全球宏观经济概览（含数据表/要点）
5. 二、大宗商品市场追踪（基本金属 + 新能源矿产）
6. 三、矿业国政策与地缘动态
7. 四、AI 评级与投资策略
8. 五、下周关注与风险提示
9. 免责声明 / AI 生成声明 / 联系方式
10. **封底**（必须存在，不可省略 ——详见封底设计规范）

**内容处理规则**：可做格式化与提炼（拆段、重排表格），但不得改变原意、不得新增数据或结论。

---

## 第三步：手写 HTML + CSS

参照 `assets/MiningClawd_MacroReport_Bilingual.html` 的结构，必须包含：

```css
@page { size: A4; margin: 0 }
.page { width: 210mm; min-height: 297mm; page-break-after: always; overflow: hidden }
```

**防溢出（强制两层）：**
1. CSS：对所有块级组件声明 `break-inside: avoid`
2. JS：PDF 输出前调用 `fixOverflow(page)`（见 `scripts/splitOverflow.cjs`）

**必须实现的组件：** `.cover`（封面光效）、`.content-page`（侧栏+主栏布局）、`.data-table`、`.key-points`、`.highlight`、`.risk-box`、`.back-cover`（封底，不可省略）

> 完整 CSS 变量、字体规范、组件模板、封底 HTML → 见 `references/style-guide.md`

## 第四步：如需插入图表，生成纯 SVG 图表

每个图表请依照如下流程：
1. 从 Word 原文提取序列数据（数值 + 时间/分类标签）
2. 使用 Node.js 脚本手动计算坐标轴、刻度、折线点/柱状条、标注，输出 SVG 字符串（`polyline/path/rect/circle/text` 等）
3. Playwright 渲染 SVG 时，**SVG 宽度固定为 1040px，高度为 640px，padding 为 100**；字体大小需为目标显示字号的 2 倍（如目标显示 12px，SVG 内写 `font-size="24"`）；截图使用 `deviceScaleFactor: 2`，输出 PNG 为 2080×1280px，确保导出图片高分辨率、细节清晰
4. 图表元素（线条、区域、柱子、刻度、图例等）配色需参考附件 HTML 的样式范例，充分丰富用色，突出数据分组/类别，避免单一色调
5. 完成截图 PNG 后，将其 base64 编码，嵌入主体 HTML：`<img src="data:image/png;base64,...">`

**注意**：
- 严禁使用 Chart.js / ECharts 等第三方图表库或调用任何在线图表服务
- 必须保证配色效果与assets里的HTML文件中规定的”图表配色规范”一致

**图表配色规范**（参考 assets HTML）：

| 图表类型 | 颜色代码 | 用途 | 补充说明 |
|---|---|---|---|
| 折线图（主线）| `#14b8a6` | 中国/主要指标 | 线宽 2.5px，圆点 r=3.5 |
| 折线图（辅线1）| `#3b82f6` | US 美国 | 线宽 2px，圆点 r=3 |
| 折线图（辅线2）| `#f59e0b` | Eurozone 欧元区 | 线宽 2px |
| 折线图（辅线3）| `#06b6d4` | India 印度 | 线宽 2px |
| 折线图（辅线4）| `#f43f5e` | Japan 日本 | 线宽 2px |
| 面积图填充 | 品牌色渐变 | 价格走势区域 | 顶部 20% 透明度 → 底部 2% |
| 柱状图（正值）| `#14b8a6` | 上涨/正向指标 | 圆角 3px，85% 透明度 |
| 柱状图（负值）| `#ef4444` | 下跌/负向指标 | 圆角 3px，85% 透明度 |
| 柱状图（辅色）| 品牌色35% | 次要数据（如核心CPI）| 与主色形成深浅对比 |
| 环形图 | 五档评级色系 | Strong Buy→Sell | 中空率 55%，白色间隔 2px |
| 参考线 | `#f87171` | 荣枯线/基准线 | 虚线 dasharray="4 3"，60% 透明度 |
| 网格线 | 黑色5% | Y 轴水平辅助线 | 0.5px 宽度 |

**图表样式要求**：
- 线条粗细：主要数据线 2.5px（r=3.5），辅助线 2px（r=3）
- 坐标轴：`#6b7280` 1.5px
- 数据标签：10-12px，`#374151`
- 图例：9px，圆形标记 8px
- 背景：纯白 `#ffffff` 或透明
- **数据来源标注**：所有图表底部标注"数据来源：xxx, MiningClawd AI 整理"，8px 浅灰色居中


---

## 封底设计规范（Back Cover）

**强制要求**：每份报告必须以 `.back-cover` 页结尾。完整 HTML 模板见 `references/style-guide.md`。

关键 CSS：`page-break-after: auto`（防末尾空白页）

## 大宗商品颜色规范（Commodity Color System）

每种商品拥有独立识别色，完整 CSS 变量（`--cu`、`--au`、`--li` 等）和工具类（`.comm`、`.comm-pill`）见 `references/style-guide.md`。

核心原则：商品色仅标识品种，涨跌方向仍用 `#22c55e`（上涨）/ `#ef4444`（下跌）。

## 第五步：Playwright 输出 PDF

```js
const { fixOverflow } = require('./scripts/splitOverflow.cjs');

await page.goto('file://' + htmlPath, { waitUntil: 'networkidle' });
await fixOverflow(page);   // ← 必须在 pdf() 之前调用，自动修复溢出并更新页码

await page.pdf({
  path: outputPath,
  format: 'A4',
  printBackground: true,   // 必须，确保深色封面与渐变保留
  preferCSSPageSize: true
});
```

文件名由用户指定；未指定时按报告日期生成（如 `MiningClawd_MacroReport_2026-03-12.pdf`）。

---

## 第六步：输出前自检

输出 PDF 前逐项确认：

- [ ] **内容一致性**：每段正文/每个数字/每条要点均可在 Word 原文找到对应来源
- [ ] **样式一致性**：封面光效、分栏、组件、颜色语义、图标配色与附件 HTML 一致
- [ ] **字体规范**：所有字号符合投行标准，正文 11.5px，标题 17px/13.5px
- [ ] **分页完整**：`.page` 严格分页，无内容溢出/裁切
- [ ] **PDF 背景**：`printBackground: true` 已启用，深色封面与渐变正常渲染
- [ ] **图表质量**：所有图表清晰（2080×1280px），配色符合规范
- [ ] **侧栏数据**：每页侧栏包含章节摘要、关键数据、页码
- [ ] **封底存在**：HTML 末尾有 `.back-cover` 页，包含 Logo、三栏信息、免责声明、版权行，且设置了 `page-break-after:auto`

任一项不通过 → 回到对应步骤修正后再输出。

---

## 常见问题处理

### Q1: 如何处理超长表格？
**A**: 将表格拆分到多页，每页重复表头。使用 `page-break-inside: avoid` 防止行被截断。

### Q2: 封面光效不显示？
**A**: 确保 `printBackground: true` 已设置，检查 `.glow1/.glow2/.glow3` 的 `position: absolute` 和 `z-index`。

### Q3: 中英文字体不一致？
**A**: 使用 `font-family: 'Noto Sans SC', 'Inter', sans-serif` 确保中文优先使用 Noto Sans SC，英文使用 Inter。

### Q4: 图表模糊？
**A**: 确保 SVG 渲染时使用 `deviceScaleFactor: 2`，输出 PNG 尺寸为 2080×1280px。

### Q5: 侧栏内容溢出？
**A**: 控制侧栏内容长度，摘要不超过 80 字，关键数据不超过 8 项。使用 `overflow: hidden` 防止溢出。

---

## 完整生成流程示例

```javascript
const { chromium } = require('playwright');
const { fixOverflow } = require('./scripts/splitOverflow.cjs');
const fs = require('fs');

async function generateReport() {
  // 1. 构建 HTML（包含所有样式和内容）
  const html = `<!DOCTYPE html>
<html lang="zh">
<head>
  <meta charset="utf-8">
  <title>MiningClawd 宏观经济报告</title>
  <style>
    @page { size: A4; margin: 0 }
    body { font-family: 'Noto Sans SC', 'Inter', sans-serif; font-size: 12px; }
    .page { width: 210mm; min-height: 297mm; page-break-after: always; overflow: hidden }

    /* 防溢出第一层：禁止在组件内部跨页截断 */
    .key-points, .data-table, .risk-box, .highlight, .disclaimer, .sb-section {
      break-inside: avoid;
      page-break-inside: avoid;
    }

    /* ... 其他样式参考 assets/MiningClawd_MacroReport_Bilingual.html ... */
  </style>
</head>
<body>
  <!-- 封面页 -->
  <div class="page cover">...</div>

  <!-- 内容页 -->
  <div class="page">
    <div class="content-page">
      <div class="sidebar-col">...</div>
      <div class="main-col">...</div>
    </div>
  </div>
</body>
</html>`;

  // 2. 写入临时文件
  fs.writeFileSync('/tmp/report.html', html, 'utf8');

  // 3. 使用 Playwright 生成 PDF
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto('file:///tmp/report.html', { waitUntil: 'networkidle' });

  // 防溢出第二层：自动检测并修复溢出（必须在 pdf() 之前）
  await fixOverflow(page);

  await page.pdf({
    path: 'MiningClawd_MacroReport_2026-03-12.pdf',
    format: 'A4',
    printBackground: true,
    preferCSSPageSize: true
  });

  await browser.close();
  console.log('PDF 生成完成');
}

generateReport().catch(console.error);
```

---

## 参考资源

- **样式模板**：`assets/MiningClawd_MacroReport_Bilingual.html`
- **设计规范**：模板文件第 6-8 页附录（品牌/字体/布局、组件/图表/侧栏、大宗商品颜色）
- **字体文件**：Google Fonts - Noto Sans SC, Inter, Space Grotesk
- **Playwright 文档**：https://playwright.dev/docs/api/class-page#page-pdf
