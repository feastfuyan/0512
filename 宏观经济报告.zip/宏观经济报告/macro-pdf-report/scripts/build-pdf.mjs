/**
 * build-pdf.mjs
 * MiningClawd 宏观经济报告 PDF 生成主入口
 *
 * 用法：
 *   node scripts/build-pdf.mjs --input report-data.json --output MiningClawd_Report.pdf
 *   node scripts/build-pdf.mjs --input report-data.json  (输出文件名自动按日期生成)
 *
 * report-data.json 结构：
 *   {
 *     "title": "全球矿业宏观经济周度观察报告",
 *     "category": "宏观研究",
 *     "date": "2026.03.19",
 *     "period": "2026.03.10 — 2026.03.16",
 *     "commodities": ["gold", "copper", "uranium", "lithium"],
 *     "content_source": "/path/to/source.docx.txt",
 *     "sections": { ... }  // 可选，直接传内容
 *   }
 */

import { chromium } from 'playwright';
import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const require = createRequire(import.meta.url);
const { fixOverflow } = require('./splitOverflow.cjs');

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SKILL_ROOT = path.resolve(__dirname, '..');
const REFS_ROOT  = path.join(SKILL_ROOT, 'references', 'expert-insights');
const ASSETS_DIR = path.join(SKILL_ROOT, 'assets');

// ─────────────────────────────────────────
// CLI 参数解析
// ─────────────────────────────────────────
function parseArgs() {
  const args = process.argv.slice(2);
  const opts = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--input')  opts.input  = args[i + 1];
    if (args[i] === '--output') opts.output = args[i + 1];
    if (args[i] === '--html')   opts.htmlOnly = true;  // 只生成HTML，不生成PDF（调试用）
  }
  if (!opts.input) {
    console.error('用法: node scripts/build-pdf.mjs --input <report-data.json> [--output <output.pdf>] [--html]');
    process.exit(1);
  }
  return opts;
}

// ─────────────────────────────────────────
// References 加载器
// ─────────────────────────────────────────
function loadReferences(commodities = []) {
  const refs = {
    rickRule: null,
    philosophy: null,
    expressions: {},
    frameworks: {},
    commodityInsights: {}
  };

  // Rick Rule 核心内容
  const rrKeyInsights = path.join(REFS_ROOT, '01_rick-rule', 'key-insights.json');
  const rrPhilosophy  = path.join(REFS_ROOT, '01_rick-rule', 'investment-philosophy.json');
  if (fs.existsSync(rrKeyInsights))  refs.rickRule   = JSON.parse(fs.readFileSync(rrKeyInsights,  'utf-8'));
  if (fs.existsSync(rrPhilosophy))   refs.philosophy = JSON.parse(fs.readFileSync(rrPhilosophy,   'utf-8'));

  // 表达模板
  const exprDir = path.join(REFS_ROOT, '03_expression-templates');
  for (const fname of fs.readdirSync(exprDir)) {
    if (!fname.endsWith('.json')) continue;
    const key = fname.replace('.json', '');
    refs.expressions[key] = JSON.parse(fs.readFileSync(path.join(exprDir, fname), 'utf-8'));
  }

  // 分析框架
  const anaDir = path.join(REFS_ROOT, '04_analysis-frameworks');
  for (const fname of fs.readdirSync(anaDir)) {
    if (!fname.endsWith('.json')) continue;
    const key = fname.replace('.json', '');
    refs.frameworks[key] = JSON.parse(fs.readFileSync(path.join(anaDir, fname), 'utf-8'));
  }

  // 商品专项 insights（按报告涉及的商品加载）
  const coreDir = path.join(REFS_ROOT, '02_core-content');
  for (const commodity of commodities) {
    const fpath = path.join(coreDir, `${commodity}-insights.json`);
    if (fs.existsSync(fpath)) {
      refs.commodityInsights[commodity] = JSON.parse(fs.readFileSync(fpath, 'utf-8'));
    }
  }

  return refs;
}

// ─────────────────────────────────────────
// 专家引用提取（从 references 库自动拉取）
// ─────────────────────────────────────────
function pickQuotes(refs, commodity, category = 'authority_statement', count = 3) {
  const data = refs.commodityInsights[commodity];
  if (!data) return [];
  const pool = data.references_by_category?.[category] || [];
  return pool.slice(0, count).map(q => ({
    text: q.text,
    expert: q.expert,
    source: q.source_title
  }));
}

// ─────────────────────────────────────────
// HTML 构建器（核心）
// ─────────────────────────────────────────
function buildHtml(reportData, refs) {
  const { title, category, date, period, sections = {} } = reportData;

  // 从 references 自动注入专家引用
  const commodities = reportData.commodities || [];
  const injectedQuotes = {};
  for (const c of commodities) {
    injectedQuotes[c] = {
      authority:  pickQuotes(refs, c, 'authority_statement', 2),
      risk:       pickQuotes(refs, c, 'risk_assessment', 2),
      data:       pickQuotes(refs, c, 'data_citation', 2),
    };
  }

  // 加载参考模板 HTML（提取 CSS 部分复用）
  const templatePath = path.join(ASSETS_DIR, 'MiningClawd_MacroReport_Bilingual.html');
  const templateHtml = fs.existsSync(templatePath) ? fs.readFileSync(templatePath, 'utf-8') : '';

  // 提取 CSS（<style> 块）
  const cssMatch = templateHtml.match(/<style[^>]*>([\s\S]*?)<\/style>/);
  const css = cssMatch ? cssMatch[1] : '';

  // 构建 keyPoints（报告要点）
  const keyPoints = sections.key_points || [
    '本周宏观数据显示全球经济韧性持续，大宗商品需求支撑未明显减弱',
    '资源品种分化加剧：铀、铜供给约束持续，锂、钴市场承压',
    '地缘政治风险溢价推升能源价格，建议适当配置能源板块',
  ];

  return `<!DOCTYPE html>
<html lang="zh">
<head>
  <meta charset="utf-8">
  <title>${title}</title>
  <style>
    @page { size: A4; margin: 0 }
    body { margin: 0; padding: 0; }
    .page { width: 210mm; min-height: 297mm; page-break-after: always; overflow: hidden; }
    .key-points, .data-table, .risk-box, .highlight, .disclaimer, .sb-section {
      break-inside: avoid; page-break-inside: avoid;
    }
    ${css}
  </style>
</head>
<body>

  <!-- 封面 -->
  <div class="page cover">
    <div class="glow1"></div><div class="glow2"></div><div class="glow3"></div>
    <div class="streak"></div><div class="streak2"></div>
    <div class="cover-inner">
      <div class="eyebrow">MININGCLAWD INTELLIGENCE SYSTEMS</div>
      <h1>${title}</h1>
      <div class="subtitle">${category} · AI-Powered Research</div>
      <div class="cover-meta">
        <span class="cover-date">${date}</span>
        ${period ? `<span class="cover-period">${period}</span>` : ''}
      </div>
      <div class="cover-badges">
        <span class="badge">AI GENERATED</span>
        <span class="badge">INSTITUTIONAL</span>
      </div>
    </div>
  </div>

  <!-- 报告要点 -->
  <div class="page">
    <div class="content-page">
      <div class="sidebar-col">
        <div class="page-header-bar"></div>
        <div class="sb-section">
          <div class="sb-title">本期摘要</div>
          ${keyPoints.map(p => `<div class="sb-highlight">▸ ${p.slice(0, 40)}...</div>`).join('')}
        </div>
        <div class="sb-pagenum">Page 2 / ?</div>
      </div>
      <div class="main-col">
        <div class="page-header">报告要点 <span class="badge-ai">AI GENERATED</span></div>
        <div class="key-points">
          <div class="kp-title">KEY INSIGHTS</div>
          <ul>
            ${keyPoints.map(p => `<li>${p}</li>`).join('')}
          </ul>
        </div>
        ${sections.macro_overview ? `
        <h2>一、全球宏观概览</h2>
        <p>${sections.macro_overview}</p>` : ''}
      </div>
    </div>
  </div>

  <!-- 大宗商品追踪 -->
  ${commodities.length > 0 ? `
  <div class="page">
    <div class="content-page">
      <div class="sidebar-col">
        <div class="sb-section">
          <div class="sb-title">专家观点</div>
          ${commodities.slice(0,2).flatMap(c =>
            (injectedQuotes[c]?.authority || []).slice(0,1).map(q =>
              `<div class="sb-item"><span class="comm-pill">${c.toUpperCase()}</span> ${q.expert}: "${q.text.slice(0,60)}..."</div>`
            )
          ).join('')}
        </div>
        <div class="sb-pagenum">Page 3 / ?</div>
      </div>
      <div class="main-col">
        <div class="page-header">二、大宗商品市场追踪</div>
        ${sections.commodities || '<p>（大宗商品数据待填入）</p>'}
        ${commodities.map(c => {
          const q = injectedQuotes[c]?.authority?.[0];
          return q ? `
          <div class="highlight">
            <strong>${q.expert}</strong> on ${c}: "${q.text}"
            <div style="font-size:9px;color:#94a3b8;margin-top:4px">Source: ${q.source} · Money of Mine</div>
          </div>` : '';
        }).join('')}
      </div>
    </div>
  </div>` : ''}

  <!-- 风险提示 -->
  <div class="page">
    <div class="content-page">
      <div class="sidebar-col">
        <div class="sb-section">
          <div class="sb-title">风险监控</div>
          <div class="sb-item">▼ 政策风险</div>
          <div class="sb-item">▼ 地缘风险</div>
          <div class="sb-item">● 供需风险</div>
        </div>
        <div class="sb-pagenum">Page 4 / ?</div>
      </div>
      <div class="main-col">
        <div class="page-header">三、风险提示</div>
        <div class="risk-box">
          <div class="rtitle">⚠ 主要风险因子</div>
          <ul>
            ${(sections.risks || [
              '美联储政策转向风险：利率路径不确定性仍高',
              '地缘政治供应中断：关键矿产供应链脆弱性上升',
              '大宗商品周期反转：部分品种涨幅已充分定价'
            ]).map(r => `<li>${r}</li>`).join('')}
          </ul>
        </div>
        ${sections.investment_view ? `
        <h2>四、AI评级与投资建议</h2>
        <p>${sections.investment_view}</p>` : ''}
      </div>
    </div>
  </div>

  <!-- 封底 -->
  <div class="page back-cover">
    <div class="glow1" style="top:55%;opacity:0.6"></div>
    <div class="glow2" style="bottom:auto;top:8%;opacity:0.6"></div>
    <div class="glow3" style="right:auto;left:18%;top:42%;opacity:0.45"></div>
    <div class="streak" style="top:36%"></div>
    <div class="streak2" style="top:63%"></div>
    <div class="bc-top">
      <div style="font-size:8px;color:#374151;letter-spacing:2px;text-transform:uppercase">End of Report · 报告完结</div>
      <div style="font-size:8px;color:#374151">MiningClawd Intelligence Systems</div>
    </div>
    <div class="bc-center">
      <div style="margin-top:18px">
        <span style="font-family:'Space Grotesk',sans-serif;font-weight:700;font-style:italic;font-size:30px">
          <span style="color:#fff">Mining</span><span style="color:#14b8a6">Clawd</span>
        </span>
      </div>
      <div style="font-size:10px;color:#14b8a6;letter-spacing:3.5px;text-transform:uppercase;margin-top:7px">Mining Intelligence · AI-Powered</div>
      <div class="bc-divider"></div>
      <div class="bc-info">
        <div><div class="bc-col-title">About</div><div class="bc-col-body">MiningClawd 是基于 AI 多因子模型的矿业经济研究平台。</div></div>
        <div><div class="bc-col-title">Coverage</div><div class="bc-col-body"><strong>宏观研究</strong> · 大宗商品</strong> · <strong>矿业投资</strong></div></div>
        <div><div class="bc-col-title">Frequency</div><div class="bc-col-body">周报 / 月报 / 专题</div></div>
      </div>
    </div>
    <div class="bc-bottom">
      <div class="disclaimer">本报告由 AI 自动生成，仅供参考，不构成投资建议。投资有风险，入市需谨慎。</div>
      <div style="font-size:7px;color:#374151;margin-top:6px">© ${new Date().getFullYear()} MiningClawd Intelligence Systems · All Rights Reserved</div>
    </div>
  </div>

</body>
</html>`;
}

// ─── Main ────────────────────────────────────────────────────────────────────
async function main() {
  const args = process.argv.slice(2);
  const jsonPath = args[0];
  const outPath  = args[1] || 'report.pdf';

  if (!jsonPath) {
    console.error('Usage: node build-pdf.mjs <report.json> [output.pdf]');
    process.exit(1);
  }

  const raw     = fs.readFileSync(jsonPath, 'utf8');
  const payload = JSON.parse(raw);

  console.log('Building PDF for:', payload.title);

  const html = buildHtml(payload);
  const tmpHtml = jsonPath.replace(/\.json$/, '.html');
  fs.writeFileSync(tmpHtml, html, 'utf8');
  console.log('HTML written to:', tmpHtml);

  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'] });
  const page    = await browser.newPage();
  await page.goto(`file://${path.resolve(tmpHtml)}`, { waitUntil: 'networkidle0' });
  await page.pdf({
    path:   path.resolve(outPath),
    format: 'A4',
    printBackground: true,
    margin: { top: 0, bottom: 0, left: 0, right: 0 },
  });
  await browser.close();

  console.log('PDF saved to:', outPath);
}

main().catch(err => { console.error(err); process.exit(1); });
