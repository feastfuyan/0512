/**
 * inject-references.mjs
 * 根据报告涉及的商品/主题，自动从 references 库拉取专家引用
 * 并注入到报告 HTML 的对应章节中。
 *
 * 用法（作为模块导入）：
 *   import { injectReferences } from './inject-references.mjs';
 *   const enrichedSections = injectReferences(sections, commodities);
 *
 * 用法（CLI 调试）：
 *   node scripts/inject-references.mjs --commodity uranium --category authority_statement --count 3
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REFS_ROOT  = path.resolve(__dirname, '..', 'references', 'expert-insights');

// ─────────────────────────────────────────
// 商品名称标准化映射
// ─────────────────────────────────────────
const COMMODITY_ALIASES = {
  // 英文
  gold: 'gold', silver: 'silver', copper: 'copper',
  uranium: 'uranium', lithium: 'lithium', cobalt: 'cobalt',
  oil: 'oil', gas: 'oil', energy: 'energy',
  aluminium: 'aluminium', aluminum: 'aluminium',
  coal: 'coal', iron: 'metals', steel: 'metals',
  metals: 'metals', macro: 'macro', mining: 'mining-equities',
  // 中文
  '黄金': 'gold', '白银': 'silver', '铜': 'copper',
  '铀': 'uranium', '锂': 'lithium', '钴': 'cobalt',
  '石油': 'oil', '原油': 'oil', '天然气': 'energy',
  '铝': 'aluminium', '煤炭': 'coal', '铁矿': 'metals',
  '金属': 'metals', '宏观': 'macro', '矿业': 'mining-equities',
};

// 样本类别优先级（报告不同章节用不同类别）
const SECTION_CATEGORY_MAP = {
  overview:      ['authority_statement', 'certainty_judgment'],
  commodities:   ['authority_statement', 'data_citation'],
  risk:          ['risk_assessment', 'authority_statement'],
  advice:        ['professional_advice', 'certainty_judgment'],
  conclusion:    ['authority_statement', 'analytical_logic'],
  sidebar:       ['certainty_judgment', 'data_citation'],
};

// ─────────────────────────────────────────
// 核心：从 references 库拉取引用
// ─────────────────────────────────────────

/**
 * 加载单个商品的 insights 文件
 */
function loadCommodityInsights(commodity) {
  const normalized = COMMODITY_ALIASES[commodity] || commodity;
  const fpath = path.join(REFS_ROOT, '02_core-content', `${normalized}-insights.json`);
  if (!fs.existsSync(fpath)) return null;
  return JSON.parse(fs.readFileSync(fpath, 'utf-8'));
}

/**
 * 加载 Rick Rule 核心引用
 */
function loadRickRuleInsights() {
  const fpath = path.join(REFS_ROOT, '01_rick-rule', 'key-insights.json');
  if (!fs.existsSync(fpath)) return null;
  return JSON.parse(fs.readFileSync(fpath, 'utf-8'));
}

/**
 * 加载表达模板
 */
function loadExpressionTemplates(templateName) {
  const fpath = path.join(REFS_ROOT, '03_expression-templates', `${templateName}.json`);
  if (!fs.existsSync(fpath)) return null;
  return JSON.parse(fs.readFileSync(fpath, 'utf-8'));
}

/**
 * 从指定商品的 insights 中按类别抽取引用
 * @param {string} commodity - 商品名（中英文均可）
 * @param {string} category  - 样本类别
 * @param {number} count     - 取几条
 * @param {object} opts      - { minLength: 60, maxLength: 300 }
 * @returns {Array<{text, expert, source_title, url}>}
 */
export function pickQuotes(commodity, category, count = 2, opts = {}) {
  const { minLength = 60, maxLength = 300 } = opts;
  const data = loadCommodityInsights(commodity);
  if (!data) return [];

  const pool = (data.references_by_category?.[category] || []).filter(q =>
    q.text && q.text.length >= minLength && q.text.length <= maxLength
  );

  // 打乱后取前 count 条，避免每次都是同样的开头
  const shuffled = pool.sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count).map(q => ({
    text:         q.text,
    expert:       q.expert || 'Money of Mine',
    source_title: q.source_title || '',
    channel:      q.channel || 'Money of Mine',
    url:          q.url || '',
    category:     category,
    commodity:    COMMODITY_ALIASES[commodity] || commodity,
  }));
}

/**
 * 为报告各章节自动注入专家引用
 * @param {string[]} commodities - 报告涉及的商品列表
 * @returns {object} injected - 按 section 和 commodity 分组的引用
 */
export function buildInjectedRefs(commodities = []) {
  const injected = {
    bySection: {},
    byCommodity: {},
    rickRule: [],
    riskPhrases: null,
    conclusionTemplates: null,
  };

  // Rick Rule 引用（权威背书用）
  const rr = loadRickRuleInsights();
  if (rr) {
    injected.rickRule = (rr.insights || []).slice(0, 3).map(i => ({
      text:    i.quote,
      expert:  'Rick Rule',
      theme:   i.theme,
      section: i.report_section,
    }));
  }

  // 表达模板
  injected.riskPhrases        = loadExpressionTemplates('risk-assessment-phrases');
  injected.conclusionTemplates = loadExpressionTemplates('conclusion-templates');

  // 各章节各商品引用
  for (const [section, categories] of Object.entries(SECTION_CATEGORY_MAP)) {
    injected.bySection[section] = {};
    for (const commodity of commodities) {
      const quotes = [];
      for (const cat of categories) {
        quotes.push(...pickQuotes(commodity, cat, 1));
        if (quotes.length >= 2) break;
      }
      if (quotes.length > 0) {
        injected.bySection[section][commodity] = quotes;
      }
    }
  }

  // 按商品汇总（全类别）
  for (const commodity of commodities) {
    const data = loadCommodityInsights(commodity);
    if (!data) continue;
    injected.byCommodity[commodity] = {
      name:    commodity,
      sources: data.sources || [],
      counts:  Object.fromEntries(
        Object.entries(data.references_by_category || {}).map(([k, v]) => [k, v.length])
      ),
      top: {
        authority: pickQuotes(commodity, 'authority_statement', 2),
        risk:      pickQuotes(commodity, 'risk_assessment', 1),
        data:      pickQuotes(commodity, 'data_citation', 2),
        advice:    pickQuotes(commodity, 'professional_advice', 1),
      }
    };
  }

  return injected;
}

/**
 * 将专家引用渲染为 HTML highlight 块
 */
export function renderQuoteHtml(quote, style = 'highlight') {
  if (!quote || !quote.text) return '';
  const sourceLabel = [quote.expert, quote.source_title].filter(Boolean).join(' — ');
  if (style === 'highlight') {
    return `<div class="highlight">
  ${quote.text}
  <div style="font-size:9px;color:#94a3b8;margin-top:4px">— ${sourceLabel} · Money of Mine</div>
</div>`;
  }
  if (style === 'sidebar') {
    return `<div class="sb-item">
  <span style="font-size:9px;color:#14b8a6;font-weight:600">${quote.expert}:</span>
  "${quote.text.slice(0, 80)}${quote.text.length > 80 ? '...' : ''}"
</div>`;
  }
  if (style === 'inline') {
    return `<span class="expert-quote">
  "${quote.text}" <em style="font-size:9px;color:#94a3b8">— ${quote.expert}</em>
</span>`;
  }
  return '';
}

/**
 * CLI 调试模式
 */
if (process.argv[1] && process.argv[1].endsWith('inject-references.mjs')) {
  const args = process.argv.slice(2);
  const commodity = args[args.indexOf('--commodity') + 1] || 'uranium';
  const category  = args[args.indexOf('--category')  + 1] || 'authority_statement';
  const count     = parseInt(args[args.indexOf('--count') + 1] || '3');

  console.log(`
=== pickQuotes: ${commodity} / ${category} / top ${count} ===`);
  const quotes = pickQuotes(commodity, category, count);
  quotes.forEach((q, i) => {
    console.log(`
[${i+1}] ${q.expert}`);
    console.log(`   ${q.text.slice(0, 120)}${q.text.length > 120 ? '...' : ''}`);
  });

  console.log(`
=== buildInjectedRefs: [${commodity}] ===`);
  const refs = buildInjectedRefs([commodity]);
  console.log('Rick Rule quotes:', refs.rickRule.length);
  console.log('Commodity top quotes:', JSON.stringify(refs.byCommodity[commodity]?.counts || {}, null, 2));
}
