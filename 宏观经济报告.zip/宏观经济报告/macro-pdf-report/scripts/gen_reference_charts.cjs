'use strict';
/**
 * gen_reference_charts.cjs
 * 用技能规定的 SVG→Playwright→PNG→base64 方式，
 * 重新生成 assets/MiningClawd_MacroReport_Bilingual.html 里的 5 张图表。
 *
 * 用法：node scripts/gen_reference_charts.cjs
 *
 * 尺寸说明（deviceScaleFactor:2，实际 PNG 为 2× SVG）：
 *   全宽图（chart 1/2/5）：SVG 1040×360 → PNG 2080×720
 *     容器 ~595px，max-height:200px，object-fit:contain → 缩放至 ~578×200，无空白
 *   两栏图（chart 3/4）：SVG 1040×640 → PNG 2080×1280
 *     容器 ~295px，max-height:200px，宽度为限制边 → 缩放至 ~295×182，无空白
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const HTML_PATH = path.join(__dirname, '../assets/MiningClawd_MacroReport_Bilingual.html');

const W  = 1040;
const HF = 360;   // 全宽图高度
const HH = 640;   // 两栏图高度

// 设计规范颜色
const C = {
  pri:  '#14b8a6', priD: '#0d9488',
  up:   '#22c55e', dn:   '#ef4444',
  hold: '#94a3b8',
  us:   '#3b82f6', eu:   '#8b5cf6',
  jp:   '#f43f5e', ind:  '#06b6d4',
  au:   '#f59e0b',
  cu:   '#e07b39', al:   '#94a3b8', fe:  '#dc2626',
  zn:   '#0891b2', ni:   '#64748b',
  li:   '#8b5cf6', co:   '#2563eb', ree: '#10b981',
  grid: 'rgba(0,0,0,0.05)', axis: '#6b7280',
  txt:  '#374151', light: '#9ca3af',
};

// ── 工具函数（全部接受 h 参数）────────────────────────────────────────────────

function pxY(v, min, max, h, t, b) {
  return t + (1 - (v - min) / (max - min)) * (h - t - b);
}
function pxX(i, n, l, r) {
  return l + (i / (n - 1)) * (W - l - r);
}

function grid(min, max, ticks, h, t, b, l, r) {
  const step = (max - min) / ticks;
  let out = '';
  for (let i = 0; i <= ticks; i++) {
    const v = min + i * step;
    const y = pxY(v, min, max, h, t, b).toFixed(1);
    out += `<line x1="${l}" y1="${y}" x2="${W - r}" y2="${y}" stroke="${C.grid}" stroke-width="0.5"/>`;
    out += `<text x="${l - 8}" y="${(parseFloat(y) + 5).toFixed(1)}" text-anchor="end" font-size="17" fill="${C.light}">${v % 1 === 0 ? v.toFixed(0) : v.toFixed(1)}</text>`;
  }
  return out;
}

function hline(v, min, max, h, t, b, l, r, color, label = '') {
  const y = pxY(v, min, max, h, t, b).toFixed(1);
  return `<line x1="${l}" y1="${y}" x2="${W - r}" y2="${y}" stroke="${color}" stroke-width="1.5" stroke-dasharray="6 4" opacity="0.55"/>`
    + (label ? `<text x="${W - r + 5}" y="${(parseFloat(y) + 5).toFixed(1)}" font-size="17" fill="${color}" opacity="0.7">${label}</text>` : '');
}

function polyline(series, min, max, h, t, b, l, r, color, sw) {
  const n = series.length;
  const pts = series.map((v, i) =>
    `${pxX(i, n, l, r).toFixed(1)},${pxY(v, min, max, h, t, b).toFixed(1)}`
  ).join(' ');
  return `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round"/>`;
}

function dots(series, min, max, h, t, b, l, r, color, rr) {
  const n = series.length;
  return series.map((v, i) => {
    const cx = pxX(i, n, l, r).toFixed(1);
    const cy = pxY(v, min, max, h, t, b).toFixed(1);
    return `<circle cx="${cx}" cy="${cy}" r="${rr}" fill="${color}" stroke="white" stroke-width="2.5"/>`;
  }).join('');
}

function xAxis(labels, h, b, l, r) {
  const n = labels.length;
  return labels.map((lbl, i) =>
    `<text x="${pxX(i, n, l, r).toFixed(1)}" y="${h - b + 26}" text-anchor="middle" font-size="18" fill="${C.light}">${lbl}</text>`
  ).join('');
}

/** 绘图区内右上角 inline 图例，不占底部空间 */
function inlineLegend(items, t, r) {
  const itemH = 22;
  const boxW  = 130;
  const boxH  = items.length * itemH + 10;
  const bx    = W - r - boxW;
  const by    = t + 6;
  let out = `<rect x="${bx - 6}" y="${by - 4}" width="${boxW + 8}" height="${boxH}" rx="4" fill="white" fill-opacity="0.88"/>`;
  items.forEach((item, i) => {
    const cy = by + 10 + i * itemH;
    out += `<circle cx="${bx + 6}" cy="${cy}" r="6" fill="${item.c}"/>`;
    out += `<text x="${bx + 18}" y="${cy + 5}" font-size="16" fill="${C.txt}">${item.l}</text>`;
  });
  return out;
}

function titleBlock(main, sub, h) {
  // 全宽图 h=360 时标题在顶部给出足够空间
  const ty = h === HF ? 34 : 38;
  const sy = h === HF ? 54 : 62;
  return `<text x="${W / 2}" y="${ty}" text-anchor="middle" font-size="26" font-weight="600" fill="${C.txt}">${main}</text>`
    + (sub ? `<text x="${W / 2}" y="${sy}" text-anchor="middle" font-size="17" fill="${C.light}">${sub}</text>` : '');
}

function zeroLine(min, max, h, t, b, l, r) {
  const y = pxY(0, min, max, h, t, b).toFixed(1);
  return `<line x1="${l}" y1="${y}" x2="${W - r}" y2="${y}" stroke="${C.axis}" stroke-width="1.5"/>`;
}

/** src 必传；数据来源锚定到 SVG 底边，自动写入，无法省略 */
function svgWrap(content, h, src) {
  const note = `<text x="${W / 2}" y="${h - 10}" text-anchor="middle" font-size="14" fill="${C.light}">数据来源：${src}, MiningClawd AI 整理</text>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${h}" viewBox="0 0 ${W} ${h}" style="background:#fff;font-family:system-ui,sans-serif">${content}${note}</svg>`;
}

// ── Chart 1：Global Manufacturing PMI 折线图（全宽，HF=360）────────────────────
function svgChart1() {
  const h = HF, t = 68, b = 52, l = 105, r = 55;
  const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const cn  = [49.1, 49.8, 50.0, 50.4, 50.1, 50.2];
  const us  = [49.0, 48.6, 49.1, 49.3, 48.7, 48.5];
  const eu  = [46.1, 46.5, 46.1, 45.7, 45.6, 45.8];
  const jp  = [48.8, 48.9, 49.2, 49.4, 49.6, 50.0];
  const ind = [56.5, 56.9, 57.2, 57.8, 57.5, 58.3];
  const MIN = 44, MAX = 60;
  return svgWrap(`
${titleBlock('Global Manufacturing PMI', 'Jan – Jun 2025', h)}
${grid(MIN, MAX, 8, h, t, b, l, r)}
${hline(50, MIN, MAX, h, t, b, l, r, C.dn, '50.0')}
${polyline(cn,  MIN, MAX, h, t, b, l, r, C.pri, 5)}
${polyline(us,  MIN, MAX, h, t, b, l, r, C.us,  4)}
${polyline(eu,  MIN, MAX, h, t, b, l, r, C.eu,  4)}
${polyline(jp,  MIN, MAX, h, t, b, l, r, C.jp,  4)}
${polyline(ind, MIN, MAX, h, t, b, l, r, C.ind, 4)}
${dots(cn,  MIN, MAX, h, t, b, l, r, C.pri, 6)}
${dots(us,  MIN, MAX, h, t, b, l, r, C.us,  5)}
${dots(eu,  MIN, MAX, h, t, b, l, r, C.eu,  5)}
${dots(jp,  MIN, MAX, h, t, b, l, r, C.jp,  5)}
${dots(ind, MIN, MAX, h, t, b, l, r, C.ind, 5)}
${inlineLegend([{c:C.pri,l:'China'},{c:C.us,l:'US'},{c:C.eu,l:'Eurozone'},{c:C.jp,l:'Japan'},{c:C.ind,l:'India'}], t, r)}
${xAxis(labels, h, b, l, r)}
`, h, 'Caixin, ISM, S&P Global');
}

// ── Chart 2：CPI vs Core CPI 分组柱状图（全宽，HF=360）────────────────────────
function svgChart2() {
  const h = HF, t = 68, b = 52, l = 95, r = 30;
  const groups = [
    { label: 'US 美国',        cpi: 3.0, core: 3.3, color: C.us  },
    { label: 'Eurozone 欧元区', cpi: 2.5, core: 2.9, color: C.eu  },
    { label: 'China 中国',     cpi: 0.2, core: 0.6, color: C.pri },
    { label: 'AU 澳大利亚',    cpi: 3.6, core: 4.0, color: C.au  },
  ];
  const MIN = 0, MAX = 5;
  const gW = (W - l - r) / groups.length;
  const bW = gW * 0.28;
  const gap = gW * 0.06;
  const baseY = pxY(0, MIN, MAX, h, t, b);

  let bars = '', vals = '', xlabels = '';
  groups.forEach((g, i) => {
    const gx = l + i * gW + gW / 2;
    const x1 = gx - bW - gap / 2;
    const x2 = gx + gap / 2;
    const y1 = pxY(g.cpi,  MIN, MAX, h, t, b);
    const y2 = pxY(g.core, MIN, MAX, h, t, b);
    bars += `<rect x="${x1.toFixed(1)}" y="${y1.toFixed(1)}" width="${bW.toFixed(1)}" height="${(baseY - y1).toFixed(1)}" fill="${g.color}" rx="3"/>`;
    bars += `<rect x="${x2.toFixed(1)}" y="${y2.toFixed(1)}" width="${bW.toFixed(1)}" height="${(baseY - y2).toFixed(1)}" fill="${g.color}" rx="3" opacity="0.38"/>`;
    vals  += `<text x="${(x1 + bW / 2).toFixed(1)}" y="${(y1 - 7).toFixed(1)}" text-anchor="middle" font-size="19" font-weight="600" fill="${g.color}">${g.cpi}%</text>`;
    vals  += `<text x="${(x2 + bW / 2).toFixed(1)}" y="${(y2 - 7).toFixed(1)}" text-anchor="middle" font-size="18" fill="${g.color}" opacity="0.75">${g.core}%</text>`;
    xlabels += `<text x="${gx.toFixed(1)}" y="${h - b + 26}" text-anchor="middle" font-size="17" fill="${C.light}">${g.label}</text>`;
  });

  return svgWrap(`
${titleBlock('CPI & Core CPI YoY %', 'June 2025  ▪  实色=CPI YoY  淡色=Core CPI', h)}
${grid(MIN, MAX, 5, h, t, b, l, r)}
<line x1="${l}" y1="${pxY(0, MIN, MAX, h, t, b).toFixed(1)}" x2="${W - r}" y2="${pxY(0, MIN, MAX, h, t, b).toFixed(1)}" stroke="${C.axis}" stroke-width="1.5"/>
${bars}${vals}${xlabels}
`, h, 'BLS, Eurostat, NBS, ABS');
}

// ── Chart 3（two-chart 左）：Base Metals WoW% 柱状图（两栏，HH=640）────────────
function svgChart3() {
  const h = HH, t = 80, b = 80, l = 110, r = 40;
  const metals = [
    { name: 'Cu 铜', wow: +2.3, color: C.cu },
    { name: 'Al 铝', wow: +1.1, color: C.al },
    { name: 'Fe 铁', wow: -1.2, color: C.fe },
    { name: 'Zn 锌', wow: +0.8, color: C.zn },
    { name: 'Ni 镍', wow: -0.5, color: C.ni },
  ];
  const MIN = -2.5, MAX = 3.5;
  const bW = (W - l - r) / metals.length * 0.52;
  const baseY = pxY(0, MIN, MAX, h, t, b);

  let bars = '', vals = '', xlabels = '';
  metals.forEach((m, i) => {
    const cx = l + (i + 0.5) * (W - l - r) / metals.length;
    const x  = cx - bW / 2;
    const y  = pxY(m.wow, MIN, MAX, h, t, b);
    const col = m.wow >= 0 ? C.up : C.dn;
    bars += `<rect x="${x.toFixed(1)}" y="${Math.min(y, baseY).toFixed(1)}" width="${bW.toFixed(1)}" height="${Math.abs(baseY - y).toFixed(1)}" fill="${col}" rx="3" opacity="0.85"/>`;
    const sign = m.wow >= 0 ? '+' : '';
    const vy = m.wow >= 0 ? y - 12 : y + 26;
    vals    += `<text x="${cx.toFixed(1)}" y="${vy.toFixed(1)}" text-anchor="middle" font-size="22" font-weight="700" fill="${col}">${sign}${m.wow}%</text>`;
    xlabels += `<text x="${cx.toFixed(1)}" y="${h - b + 30}" text-anchor="middle" font-size="19" font-weight="600" fill="${m.color}">${m.name}</text>`;
  });

  return svgWrap(`
${titleBlock('Base Metals WoW %', 'Week ending Jul 14, 2025', h)}
${grid(MIN, MAX, 6, h, t, b, l, r)}
${zeroLine(MIN, MAX, h, t, b, l, r)}
${bars}${vals}${xlabels}
`, h, 'LME');
}

// ── Chart 4（two-chart 右）：Base Metals YTD% 柱状图（两栏，HH=640）────────────
function svgChart4() {
  const h = HH, t = 80, b = 80, l = 110, r = 40;
  const metals = [
    { name: 'Cu 铜', ytd: +12.5, color: C.cu },
    { name: 'Al 铝', ytd:  +8.2, color: C.al },
    { name: 'Zn 锌', ytd:  +6.3, color: C.zn },
    { name: 'Fe 铁', ytd:  -5.8, color: C.fe },
    { name: 'Ni 镍', ytd: -15.3, color: C.ni },
  ];
  const MIN = -18, MAX = 16;
  const bW = (W - l - r) / metals.length * 0.52;
  const baseY = pxY(0, MIN, MAX, h, t, b);

  let bars = '', vals = '', xlabels = '';
  metals.forEach((m, i) => {
    const cx = l + (i + 0.5) * (W - l - r) / metals.length;
    const x  = cx - bW / 2;
    const y  = pxY(m.ytd, MIN, MAX, h, t, b);
    const col = m.ytd >= 0 ? C.up : C.dn;
    bars += `<rect x="${x.toFixed(1)}" y="${Math.min(y, baseY).toFixed(1)}" width="${bW.toFixed(1)}" height="${Math.abs(baseY - y).toFixed(1)}" fill="${col}" rx="3" opacity="0.85"/>`;
    const sign = m.ytd >= 0 ? '+' : '';
    const vy = m.ytd >= 0 ? y - 12 : y + 26;
    vals    += `<text x="${cx.toFixed(1)}" y="${vy.toFixed(1)}" text-anchor="middle" font-size="22" font-weight="700" fill="${col}">${sign}${m.ytd}%</text>`;
    xlabels += `<text x="${cx.toFixed(1)}" y="${h - b + 30}" text-anchor="middle" font-size="19" font-weight="600" fill="${m.color}">${m.name}</text>`;
  });

  return svgWrap(`
${titleBlock('Base Metals YTD %', 'as of Jul 14, 2025', h)}
${grid(MIN, MAX, 6, h, t, b, l, r)}
${zeroLine(MIN, MAX, h, t, b, l, r)}
${bars}${vals}${xlabels}
`, h, 'LME');
}

// ── Chart 5：New Energy Minerals WoW%（全宽，HF=360）──────────────────────────
function svgChart5() {
  const h = HF, t = 68, b = 52, l = 105, r = 40;
  const metals = [
    { name: 'Li₂CO₃', wow: -2.8, color: C.li  },
    { name: 'LiOH',   wow: -3.1, color: C.li  },
    { name: 'Cobalt', wow: +0.5, color: C.co  },
    { name: 'NdPr',   wow: +1.2, color: C.ree },
  ];
  const MIN = -4, MAX = 2.5;
  const bW = (W - l - r) / metals.length * 0.46;
  const baseY = pxY(0, MIN, MAX, h, t, b);

  let bars = '', vals = '', xlabels = '';
  metals.forEach((m, i) => {
    const cx = l + (i + 0.5) * (W - l - r) / metals.length;
    const x  = cx - bW / 2;
    const y  = pxY(m.wow, MIN, MAX, h, t, b);
    const col = m.wow >= 0 ? C.up : C.dn;
    bars += `<rect x="${x.toFixed(1)}" y="${Math.min(y, baseY).toFixed(1)}" width="${bW.toFixed(1)}" height="${Math.abs(baseY - y).toFixed(1)}" fill="${col}" rx="3" opacity="0.85"/>`;
    const sign = m.wow >= 0 ? '+' : '';
    const vy = m.wow >= 0 ? y - 10 : y + 24;
    vals    += `<text x="${cx.toFixed(1)}" y="${vy.toFixed(1)}" text-anchor="middle" font-size="24" font-weight="700" fill="${col}">${sign}${m.wow}%</text>`;
    xlabels += `<text x="${cx.toFixed(1)}" y="${h - b + 26}" text-anchor="middle" font-size="20" font-weight="600" fill="${m.color}">${m.name}</text>`;
  });

  return svgWrap(`
${titleBlock('New Energy Minerals WoW %', 'Week ending Jul 14, 2025', h)}
${grid(MIN, MAX, 6, h, t, b, l, r)}
${zeroLine(MIN, MAX, h, t, b, l, r)}
${bars}${vals}${xlabels}
`, h, 'SMM, Fastmarkets');
}

// ── 主流程 ────────────────────────────────────────────────────────────────────
async function main() {
  const charts = [
    { fn: svgChart1, h: HF, name: 'PMI折线(全宽)'       },
    { fn: svgChart2, h: HF, name: 'CPI柱状(全宽)'       },
    { fn: svgChart3, h: HH, name: '基本金属WoW(两栏左)' },
    { fn: svgChart4, h: HH, name: '基本金属YTD(两栏右)' },
    { fn: svgChart5, h: HF, name: '新能源矿产WoW(全宽)' },
  ];

  const browser = await chromium.launch();
  const ctx = await browser.newContext({ deviceScaleFactor: 2 });
  const base64list = [];

  for (let i = 0; i < charts.length; i++) {
    const { fn, h, name } = charts[i];
    const svgStr = fn();
    const page = await ctx.newPage();
    await page.setViewportSize({ width: W, height: h });
    await page.setContent(
      `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#fff">${svgStr}</body></html>`,
      { waitUntil: 'domcontentloaded' }
    );
    const buf = await page.screenshot({ clip: { x: 0, y: 0, width: W, height: h } });
    await page.close();
    base64list.push(buf.toString('base64'));
    console.log(`  ✓ Chart ${i + 1}/5  ${name}  SVG ${W}×${h} → PNG ${W*2}×${h*2}`);
  }

  await browser.close();

  let html = fs.readFileSync(HTML_PATH, 'utf8');
  let count = 0;
  html = html.replace(/<img src="data:image\/png;base64,[^"]+"/g, match => {
    if (count >= base64list.length) return match;
    const out = `<img src="data:image/png;base64,${base64list[count]}"`;
    count++;
    return out;
  });

  fs.writeFileSync(HTML_PATH, html, 'utf8');
  console.log(`\n✅ 完成：替换了 ${count} 张图表，无左右空白`);
}

main().catch(err => { console.error('❌', err); process.exit(1); });
